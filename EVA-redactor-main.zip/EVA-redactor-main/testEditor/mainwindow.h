#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QLabel>
#include <QGraphicsPixmapItem>
#include <QFileDialog>
#include "image.h"
#include "twowindow.h"

QT_BEGIN_NAMESPACE
namespace Ui {class MainWindow;}
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:


    void on_graphicsView_rubberBandChanged(const QRect &viewportRect, const QPointF &fromScenePoint, const QPointF &toScenePoint);

    void on_actionOpen_triggered();

    void on_actionExit_triggered();





    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_8_clicked();

    void on_toolButton_clicked();

    void on_toolButton_2_clicked();

    void on_actionClose_triggered();

    void on_actionSave_2_triggered();

    void on_horizontalSlider_valueChanged(int value);

    void on_horizontalSlider_2_valueChanged(int value);

    void on_horizontalSlider_3_valueChanged(int value);

    void on_horizontalSlider_4_valueChanged(int value);

    void on_pushButton_9_clicked();





private:
    Ui::MainWindow *ui;

    QGraphicsScene scene;
    QGraphicsPixmapItem* pixmapItem;
    std::unique_ptr<image> activeImage;
    QList<double> zoomList;
protected slots:
    //    void resizeEvent(QResizeEvent *event) override;
    void zoomUpdate(bool increment);


};
#endif // MAINWINDOW_H
