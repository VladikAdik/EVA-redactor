#ifndef SECONDWINDOW_H
#define SECONDWINDOW_H
#include <QDebug>
#include <QDialog>
#include <QFileDialog>
#include <QImageWriter>
#include <QInputDialog>
#include <QList>
#include <QMessageBox>
#include <QWidget>

class SecondWindow
{
public:
    SecondWindow(QWidget *parent);
    ~SecondWindow();
};

#endif // SECONDWINDOW_H
