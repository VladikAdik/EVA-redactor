#ifndef CROP_H
#define CROP_H

int truncate0_255(int value);

int truncate_m100_100(int value);

int truncate0_100(int value);

#endif // CROP_H
